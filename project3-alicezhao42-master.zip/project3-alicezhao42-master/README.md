# MIE250 Project3

Please see the assignment description posted on Quercus for instructions.
