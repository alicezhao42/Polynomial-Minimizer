package util;


import java.util.HashMap;

/** Implements a vector with *named* indices.  For example { x=1.0 y=2.0 } is a 2D
 *  vector with the first dimension named "x" and the second dimension named "y"
 *  and having respective values 1.0 and 2.0 in these dimensions.
 *  
 *  TODO: Implement all methods required to support the functionality of the project
 *        and that described in Vector.main(...) below.
 * 
 * @author ssanner@mie.utoronto.ca
 *
 */
public class Vector {

	private HashMap<String,Double> _hmVar2Value; // This maps dimension variable names to values
	
	/** Constructor of an initially empty Vector
	 * 
	 */
	public Vector() {
		_hmVar2Value = new HashMap<String,Double>(); //create new hashmap to store key/values of vector 
		
	}
	
	public String toString() {
		StringBuilder finalString = new StringBuilder();
		//StringBuilder termString = new StringBuilder();
		finalString.append("{ "); //start string building with curly brackets 
		HashMap<String,Double> _hash = _hmVar2Value; 
		
		for (String keys: _hash.keySet()) { //run through all the keys in hashmap 
			finalString.append(String.format("%s=%6.4f ", keys, _hash.get(keys))); //add in keys and values in this format 
		} 
		finalString.append("}");
		String _toString = finalString.toString(); //convert string builder to string 
	return _toString;
	}

	/** Constructor that parses a String s like "{ x=-1 y=-2.0 z=3d }" into 
	 *  the internal HashMap representation of the Vector.  See usage in main().
	 * 
	 * @param s
	 * @throws Exception 
	 */
	public Vector(String s) throws Exception {
		// TODO: this method should not be empty! 
		// Hint: you're going to have use String.split used in Project2.
		
		_hmVar2Value = new HashMap<String,Double>(); 
		String[] sp = s.split("\\s");  //split by white spaces
		for (int i = 1; i < (sp.length - 1); i++) { //excluding { and } 
			String[] sp2 = sp[i].split("="); //split by =
			double _val = Double.parseDouble(sp2[1]); //convert the value in string to a double
			_hmVar2Value.put(sp2[0], _val); 
		}
	}

	/** Removes (clears) all (key,value) pairs from the Vector representation
	 * 
	 */
	public void clear() {
		_hmVar2Value.clear(); 
		
	}

	/** Sets a specific var to the value val in *this*, i.e., var=val
	 * 
	 * @param var - label of Vector index to change
	 * @param val - value to change it to
	 */
	public void set(String var, double val) {
		_hmVar2Value.put(var, val); 
	}
	
	/** Sets all entries in *this* Vector to match entries in x
	 *  (if additional variables are in *this*, they remain unchanged) 
	 * 
	 * @param x
	 */
	public void setAll(Vector x) {
		_hmVar2Value.putAll(x._hmVar2Value);
	}
	
	public double get(String key) throws Exception {
		return _hmVar2Value.get(key); 
	}

	///////////////////////////////////////////////////////////////////////////////
	// TODO: Add your methods here!  You'll need more than those above to make
	//       main() work below.
	///////////////////////////////////////////////////////////////////////////////
	
	public Vector sum(Vector a) throws Exception {
		Vector _sum = new Vector(); //new vector to return
		for (String key : _hmVar2Value.keySet()) { //run through all the keys in the hashmap of this vector 
			
			double _sumVal = _hmVar2Value.get(key) + a._hmVar2Value.get(key); //get value of both vectors with this key 
			_sum.set(key, _sumVal); //set new vector with the sum of the values 
		} 
		return _sum; 
	} 
	
	public Vector scalarMult(double d) {
		Vector _scalarMult = new Vector(); //creates new vector to return 
		for (String key : _hmVar2Value.keySet()) {
		  double each_value = _hmVar2Value.get(key); //get the value corresponding to key 
		  double _putValue = each_value * d; //multiply with scalar d 
		  _scalarMult.set(key, _putValue); //set value of new vector with the original value * d 
		} 
		return _scalarMult; 
	}
	
	public double computeL2Norm() {
		double compute = 0; 
		for (String key : _hmVar2Value.keySet()) {
			double val = _hmVar2Value.get(key);  // get value at specific key 
			compute += val*val; //accumulate the square of the values
		}
		return Math.sqrt(compute); //return square root of the sum of the squares 
	}
	
	public boolean equals(Object o) {
		boolean b = false; 
		if (o instanceof Vector) { //checks if it is a vector 
			Vector v = (Vector)o;
			if (_hmVar2Value.size() == v._hmVar2Value.size()) { //check if the size of 2 vectors is the same
				for (String k : _hmVar2Value.keySet()) { //run through keys 
					if (v._hmVar2Value.get(k) != null && v._hmVar2Value.get(k).equals( _hmVar2Value.get(k))) { //if the value of that key does not equal to null (meaning it exists) & the values equal 
						b = true; //set b to true
						continue; //skip the line below to run through the rest of the values 
					} b = false; //set to false if something is not the same 
					break; //stop running the code once something is not the same 
				}
			}
		}
		return b; 
	}
	
	/** Your Vector class should implement the core functionality below and produce
	 *  **all** of the expected outputs below.  **These will be tested for grading.**
	 * 
	 *  When initially developing the code, comment out lines below that you have
	 *  not implemented yet.  This will allow your code to compile for incremental
	 *  testing.
	 *  
	 * @param args (unused -- ignore)
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// Make vector: vec1[x y z] = [1 2 3]
		Vector vec1 = new Vector();
		vec1.set("x", 1.0);
		vec1.set("y", 2.0);
		vec1.set("z", 3.0);
		
		// Make vector: vec2[x y z] = [-3 -2 -1]
		Vector vec2 = new Vector();
		vec2.set("x", -3.0);
		vec2.set("y", -2.0);
		vec2.set("z", -1.0);
		
		// Make vector: vec3[x y z] = vec4[x y z] = [-1 -2 -3]
		Vector vec3 = new Vector("{ x=-1 y=-2.0 z=3d }");
		Vector vec4 = new Vector(vec3.toString());
		
		// Hint: all numbers below are formatted with String.format("%s=%6.4f ", var, val)
		//       ... you may want to use this in your Vector.toString() implementation!
		
		// Test cases: 
		System.out.println(vec1); // Should print: { x=1.0000 y=2.0000 z=3.0000 }
		System.out.println(vec2); // Should print: { x=-3.0000 y=-2.0000 z=-1.0000 }
		System.out.println(vec3); // Should print: { x=-1.0000 y=-2.0000 z=3.0000 }
		System.out.println(vec4); // Should print: { x=-1.0000 y=-2.0000 z=3.0000 }
		System.out.println(vec1.sum(vec1));        // Should print: { x=2.0000 y=4.0000 z=6.0000 }
		System.out.println(vec1.sum(vec2));        // Should print: { x=-2.0000 y=0.0000 z=2.0000 }
		System.out.println(vec1.sum(vec3));        // Should print: { x=0.0000 y=0.0000 z=6.0000 }
		System.out.println(vec1.scalarMult(0.5));  // Should print: { x=0.5000 y=1.0000 z=1.5000 }
		System.out.println(vec2.scalarMult(-1.0)); // Should print: { x=3.0000 y=2.0000 z=1.0000 }
		System.out.println(vec1.sum(vec2.scalarMult(-1.0))); // Should print: { x=4.0000 y=4.0000 z=4.0000 }
		System.out.format("%01.3f\n", vec1.computeL2Norm());           // Should print: 3.742
		System.out.format("%01.3f\n", vec2.sum(vec3).computeL2Norm()); // Should print: 6.000
		
		// If the following don't work, did you override equals()?  See Project 2 Vector and Matrix.
		System.out.println(vec3.equals(vec1)); // Should print: false
		System.out.println(vec3.equals(vec3)); // Should print: true
		System.out.println(vec3.equals(vec4)); // Should print: true
		System.out.println(vec1.sum(vec2).equals(vec2.sum(vec1))); // Should print: true
	}	
}
